package com.example.mobilefileterminal;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private TextView outputView;
    private EditText commandInput;
    private ScrollView scrollView;
    private File currentDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentDir = Environment.getExternalStorageDirectory();
        buildUi();
        requestStoragePermission();
        printBanner();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 18, 18));
        root.setPadding(12, 12, 12, 12);

        TextView title = new TextView(this);
        title.setText("手机文件终端");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 12);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);

        Button helpButton = makeButton("命令");
        helpButton.setOnClickListener(v -> execute("help"));
        buttonRow.addView(helpButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button grantButton = makeButton("授权");
        grantButton.setOnClickListener(v -> openStorageSettings());
        buttonRow.addView(grantButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button clearButton = makeButton("清屏");
        clearButton.setOnClickListener(v -> outputView.setText(""));
        buttonRow.addView(clearButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        root.addView(buttonRow);

        scrollView = new ScrollView(this);
        outputView = new TextView(this);
        outputView.setTextColor(Color.rgb(0, 230, 118));
        outputView.setTextSize(14);
        outputView.setTypeface(android.graphics.Typeface.MONOSPACE);
        outputView.setMovementMethod(new ScrollingMovementMethod());
        outputView.setPadding(8, 8, 8, 8);
        scrollView.addView(outputView);
        root.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);

        commandInput = new EditText(this);
        commandInput.setSingleLine(true);
        commandInput.setTextColor(Color.WHITE);
        commandInput.setHintTextColor(Color.GRAY);
        commandInput.setHint("输入命令，例如 ls、pwd、help");
        commandInput.setTypeface(android.graphics.Typeface.MONOSPACE);
        commandInput.setBackgroundColor(Color.rgb(35, 35, 35));
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            runInputCommand();
            return true;
        });
        inputRow.addView(commandInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button runButton = makeButton("执行");
        runButton.setOnClickListener(v -> runInputCommand());
        inputRow.addView(runButton);

        root.addView(inputRow);
        setContentView(root);
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                }, 100);
            }
        }
    }

    private void openStorageSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
            append("请在系统设置中允许文件访问权限。");
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void printBanner() {
        append("================================");
        append("手机文件终端控制器 APK");
        append("输入 help 查看命令列表");
        append("当前目录: " + safePath(currentDir));
        append("提示: Android 未 Root 时不能访问系统保护目录。");
        append("================================");
    }

    private void runInputCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) return;
        commandInput.setText("");
        hideKeyboard();
        execute(command);
    }

    private void execute(String input) {
        append("");
        append(prompt() + input);
        String[] parts = parseCommand(input);
        if (parts.length == 0) return;
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);

        try {
            switch (cmd) {
                case "help": help(); break;
                case "pwd": append(safePath(currentDir)); break;
                case "ls": ls(args); break;
                case "cd": cd(args); break;
                case "mkdir": mkdir(args); break;
                case "touch": touch(args); break;
                case "cat": cat(args); break;
                case "rm": rm(args); break;
                case "cp": cp(args); break;
                case "mv": mv(args); break;
                case "find": find(args); break;
                case "grep": grep(args); break;
                case "head": head(args); break;
                case "tail": tail(args); break;
                case "du": du(args); break;
                case "df": df(); break;
                case "tree": tree(args); break;
                case "zip": zip(args); break;
                case "unzip": unzip(args); break;
                case "echo": echo(args); break;
                case "clear": outputView.setText(""); break;
                case "grant": openStorageSettings(); break;
                case "about": about(); break;
                case "exit": finish(); break;
                default: append("未知命令: " + cmd + "，输入 help 查看命令。");
            }
        } catch (Exception e) {
            append("错误: " + e.getMessage());
        }
    }

    private String prompt() {
        return currentDir.getAbsolutePath() + " $ ";
    }

    private void append(String text) {
        outputView.append(text + "\n");
        scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    private String[] parseCommand(String input) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuote = false;
        char quote = 0;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '"' || c == '\'') {
                if (!inQuote) {
                    inQuote = true;
                    quote = c;
                } else if (quote == c) {
                    inQuote = false;
                } else {
                    current.append(c);
                }
            } else if (Character.isWhitespace(c) && !inQuote) {
                if (current.length() > 0) {
                    result.add(current.toString());
                    current.setLength(0);
                }
            } else {
                current.append(c);
            }
        }

        if (current.length() > 0) result.add(current.toString());
        return result.toArray(new String[0]);
    }

    private File resolve(String path) throws IOException {
        File file;
        if (path.equals("~")) {
            file = Environment.getExternalStorageDirectory();
        } else if (path.startsWith("~/")) {
            file = new File(Environment.getExternalStorageDirectory(), path.substring(2));
        } else if (path.startsWith("/")) {
            file = new File(path);
        } else {
            file = new File(currentDir, path);
        }
        return file.getCanonicalFile();
    }

    private String safePath(File file) {
        try {
            return file.getCanonicalPath();
        } catch (IOException e) {
            return file.getAbsolutePath();
        }
    }

    private void help() {
        append("命令列表:");
        append("  ls [-a] [-l] [目录]        列出目录内容");
        append("  cd [目录]                  切换目录，~ 表示手机存储根目录");
        append("  pwd                        显示当前路径");
        append("  mkdir <目录>               创建目录");
        append("  touch <文件>               创建空文件");
        append("  cat <文件>                 查看文本文件");
        append("  rm [-r] <文件/目录>        删除文件或目录");
        append("  cp [-r] <源> <目标>        复制文件或目录");
        append("  mv <源> <目标>             移动或重命名");
        append("  find [目录] [关键词]       搜索文件名");
        append("  grep <文本> <文件>         搜索文件内容");
        append("  head [-n数量] <文件>       查看文件前几行");
        append("  tail [-n数量] <文件>       查看文件后几行");
        append("  du [文件/目录]             查看大小");
        append("  df                         查看存储空间");
        append("  tree [目录]                树形显示目录");
        append("  zip <包.zip> <文件/目录>   压缩");
        append("  unzip <包.zip> [目录]      解压");
        append("  echo <文本> [> 文件]       输出或写入文件");
        append("  grant                      打开文件权限设置");
        append("  clear                      清屏");
        append("  about                      关于");
        append("  exit                       退出");
    }

    private void about() {
        append("手机文件终端控制器 v1.0");
        append("这是一个普通 Android APK，不自带 Root。");
        append("如果手机未 Root，只能访问系统允许的文件目录。");
    }

    private void ls(String[] args) throws IOException {
        boolean showAll = false;
        boolean longMode = false;
        File target = currentDir;

        for (String arg : args) {
            if (arg.startsWith("-")) {
                showAll = arg.contains("a");
                longMode = arg.contains("l");
            } else {
                target = resolve(arg);
            }
        }

        if (!target.exists()) {
            append("目录不存在: " + safePath(target));
            return;
        }
        if (!target.isDirectory()) {
            append(target.getName());
            return;
        }

        File[] files = target.listFiles();
        if (files == null) {
            append("无法读取目录，可能没有权限。");
            return;
        }
        Arrays.sort(files, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) return -1;
            if (!a.isDirectory() && b.isDirectory()) return 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });

        for (File f : files) {
            if (!showAll && f.getName().startsWith(".")) continue;
            if (longMode) {
                String type = f.isDirectory() ? "d" : "-";
                String perms = type + (f.canRead() ? "r" : "-") + (f.canWrite() ? "w" : "-") + (f.canExecute() ? "x" : "-");
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(new Date(f.lastModified()));
                append(String.format(Locale.CHINA, "%s %10s %s %s", perms, sizeText(f.length()), time, f.getName() + (f.isDirectory() ? "/" : "")));
            } else {
                append(f.getName() + (f.isDirectory() ? "/" : ""));
            }
        }
    }

    private void cd(String[] args) throws IOException {
        File target = args.length == 0 ? Environment.getExternalStorageDirectory() : resolve(args[0]);
        if (!target.exists()) {
            append("目录不存在: " + safePath(target));
        } else if (!target.isDirectory()) {
            append("不是目录: " + safePath(target));
        } else {
            currentDir = target;
            append("当前目录: " + safePath(currentDir));
        }
    }

    private void mkdir(String[] args) throws IOException {
        if (args.length == 0) {
            append("用法: mkdir <目录>");
            return;
        }
        for (String arg : args) {
            File dir = resolve(arg);
            append(dir.mkdirs() ? "已创建: " + safePath(dir) : "创建失败或已存在: " + safePath(dir));
        }
    }

    private void touch(String[] args) throws IOException {
        if (args.length == 0) {
            append("用法: touch <文件>");
            return;
        }
        for (String arg : args) {
            File file = resolve(arg);
            File parent = file.getParentFile();
            if (parent != null) parent.mkdirs();
            boolean ok = file.exists() ? file.setLastModified(System.currentTimeMillis()) : file.createNewFile();
            append(ok ? "完成: " + safePath(file) : "失败: " + safePath(file));
        }
    }

    private void cat(String[] args) throws IOException {
        if (args.length == 0) {
            append("用法: cat <文件>");
            return;
        }
        for (String arg : args) {
            File file = resolve(arg);
            if (!file.isFile()) {
                append("不是文件: " + safePath(file));
                continue;
            }
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                int count = 0;
                while ((line = reader.readLine()) != null) {
                    append(line);
                    count++;
                    if (count >= 500) {
                        append("只显示前 500 行，避免卡顿。");
                        break;
                    }
                }
            }
        }
    }

    private void rm(String[] args) throws IOException {
        if (args.length == 0) {
            append("用法: rm [-r] <文件/目录>");
            return;
        }
        boolean recursive = false;
        List<String> targets = new ArrayList<>();
        for (String arg : args) {
            if (arg.startsWith("-")) recursive = arg.contains("r");
            else targets.add(arg);
        }
        for (String arg : targets) {
            File file = resolve(arg);
            if (!file.exists()) {
                append("不存在: " + safePath(file));
            } else if (file.isDirectory() && !recursive) {
                append("目录需要使用 -r 删除: " + safePath(file));
            } else {
                append(delete(file) ? "已删除: " + safePath(file) : "删除失败: " + safePath(file));
            }
        }
    }

    private boolean delete(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) delete(child);
            }
        }
        return file.delete();
    }

    private void cp(String[] args) throws IOException {
        if (args.length < 2) {
            append("用法: cp [-r] <源> <目标>");
            return;
        }
        boolean recursive = false;
        List<String> list = new ArrayList<>(Arrays.asList(args));
        if (list.remove("-r")) recursive = true;
        File source = resolve(list.get(0));
        File dest = resolve(list.get(1));
        if (!source.exists()) {
            append("源不存在: " + safePath(source));
            return;
        }
        if (source.isDirectory() && !recursive) {
            append("复制目录需要使用 -r。");
            return;
        }
        copy(source, dest.isDirectory() ? new File(dest, source.getName()) : dest);
        append("复制完成。");
    }

    private void copy(File source, File dest) throws IOException {
        if (source.isDirectory()) {
            dest.mkdirs();
            File[] files = source.listFiles();
            if (files != null) {
                for (File f : files) copy(f, new File(dest, f.getName()));
            }
        } else {
            File parent = dest.getParentFile();
            if (parent != null) parent.mkdirs();
            try (FileInputStream in = new FileInputStream(source);
                 FileOutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            }
        }
    }

    private void mv(String[] args) throws IOException {
        if (args.length < 2) {
            append("用法: mv <源> <目标>");
            return;
        }
        File source = resolve(args[0]);
        File dest = resolve(args[1]);
        if (dest.isDirectory()) dest = new File(dest, source.getName());
        append(source.renameTo(dest) ? "移动完成。" : "移动失败。");
    }

    private void find(String[] args) throws IOException {
        File dir = args.length > 0 ? resolve(args[0]) : currentDir;
        String key = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        if (!dir.isDirectory()) {
            append("不是目录: " + safePath(dir));
            return;
        }
        findRecursive(dir, key, 0);
    }

    private void findRecursive(File dir, String key, int depth) {
        if (depth > 20) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.getName().toLowerCase(Locale.ROOT).contains(key)) append(safePath(f));
            if (f.isDirectory()) findRecursive(f, key, depth + 1);
        }
    }

    private void grep(String[] args) throws IOException {
        if (args.length < 2) {
            append("用法: grep <文本> <文件>");
            return;
        }
        String key = args[0];
        File file = resolve(args[1]);
        if (!file.isFile()) {
            append("不是文件: " + safePath(file));
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNo = 0;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                if (line.contains(key)) append(lineNo + ": " + line);
            }
        }
    }

    private void head(String[] args) throws IOException {
        showLines(args, true);
    }

    private void tail(String[] args) throws IOException {
        showLines(args, false);
    }

    private void showLines(String[] args, boolean fromHead) throws IOException {
        int n = 10;
        String fileName = null;
        for (String arg : args) {
            if (arg.startsWith("-n")) n = Integer.parseInt(arg.substring(2));
            else fileName = arg;
        }
        if (fileName == null) {
            append("用法: " + (fromHead ? "head" : "tail") + " [-n数量] <文件>");
            return;
        }
        File file = resolve(fileName);
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) lines.add(line);
        }
        int start = fromHead ? 0 : Math.max(0, lines.size() - n);
        int end = fromHead ? Math.min(n, lines.size()) : lines.size();
        for (int i = start; i < end; i++) append(lines.get(i));
    }

    private void du(String[] args) throws IOException {
        File target = args.length > 0 ? resolve(args[0]) : currentDir;
        append(sizeText(sizeOf(target)) + "  " + safePath(target));
    }

    private long sizeOf(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] files = file.listFiles();
        if (files != null) {
            for (File f : files) total += sizeOf(f);
        }
        return total;
    }

    private void df() {
        File root = Environment.getExternalStorageDirectory();
        long total = root.getTotalSpace();
        long free = root.getFreeSpace();
        long used = total - free;
        append("总容量: " + sizeText(total));
        append("已使用: " + sizeText(used));
        append("可用: " + sizeText(free));
    }

    private void tree(String[] args) throws IOException {
        File dir = args.length > 0 ? resolve(args[0]) : currentDir;
        append(safePath(dir));
        printTree(dir, "", 0);
    }

    private void printTree(File dir, String prefix, int depth) {
        if (depth > 5) {
            append(prefix + "...");
            return;
        }
        File[] files = dir.listFiles();
        if (files == null) return;
        Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            boolean last = i == files.length - 1;
            append(prefix + (last ? "└── " : "├── ") + f.getName() + (f.isDirectory() ? "/" : ""));
            if (f.isDirectory()) printTree(f, prefix + (last ? "    " : "│   "), depth + 1);
        }
    }

    private void zip(String[] args) throws IOException {
        if (args.length < 2) {
            append("用法: zip <压缩包.zip> <文件/目录>");
            return;
        }
        File out = resolve(args[0]);
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            for (int i = 1; i < args.length; i++) {
                File src = resolve(args[i]);
                addZip(zos, src, src.getName());
            }
        }
        append("压缩完成: " + safePath(out));
    }

    private void addZip(ZipOutputStream zos, File file, String name) throws IOException {
        if (file.isDirectory()) {
            zos.putNextEntry(new ZipEntry(name + "/"));
            zos.closeEntry();
            File[] files = file.listFiles();
            if (files != null) {
                for (File f : files) addZip(zos, f, name + "/" + f.getName());
            }
        } else {
            zos.putNextEntry(new ZipEntry(name));
            try (FileInputStream in = new FileInputStream(file)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) > 0) zos.write(buf, 0, len);
            }
            zos.closeEntry();
        }
    }

    private void unzip(String[] args) throws IOException {
        if (args.length < 1) {
            append("用法: unzip <压缩包.zip> [目录]");
            return;
        }
        File zip = resolve(args[0]);
        File dest = args.length > 1 ? resolve(args[1]) : currentDir;
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zip))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File out = new File(dest, entry.getName());
                if (entry.isDirectory()) {
                    out.mkdirs();
                } else {
                    File parent = out.getParentFile();
                    if (parent != null) parent.mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        byte[] buf = new byte[8192];
                        int len;
                        while ((len = zis.read(buf)) > 0) fos.write(buf, 0, len);
                    }
                }
                zis.closeEntry();
            }
        }
        append("解压完成。");
    }

    private void echo(String[] args) throws IOException {
        StringBuilder text = new StringBuilder();
        String outFile = null;
        boolean appendMode = false;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals(">") || args[i].equals(">>")) {
                appendMode = args[i].equals(">>");
                if (i + 1 < args.length) outFile = args[++i];
            } else {
                if (text.length() > 0) text.append(" ");
                text.append(args[i]);
            }
        }
        if (outFile == null) {
            append(text.toString());
        } else {
            try (FileWriter writer = new FileWriter(resolve(outFile), appendMode)) {
                writer.write(text.toString());
                writer.write("\n");
            }
            append("写入完成。");
        }
    }

    private String sizeText(long bytes) {
        if (bytes < 1024) return bytes + "B";
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) {
            value /= 1024;
            unit++;
        }
        return String.format(Locale.CHINA, "%.1f%s", value, units[unit]);
    }
}
